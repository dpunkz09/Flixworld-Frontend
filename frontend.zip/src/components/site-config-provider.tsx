"use client";

import { useMemo, type ReactNode } from "react";
import { SiteConfigContext, useSiteConfigProvider } from "@/hooks/useSiteConfig";

export default function SiteConfigProvider({ children }: { children: ReactNode }) {
  const config = useSiteConfigProvider();
  // Memoize so downstream consumers only re-render when config actually changes
  const value = useMemo(() => config, [config]);
  return (
    <SiteConfigContext.Provider value={value}>
      {children}
    </SiteConfigContext.Provider>
  );
}
