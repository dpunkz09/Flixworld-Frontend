import type { MetadataRoute } from "next";

export default function robots(): MetadataRoute.Robots {
  const base = "https://flixworld.xyz";
  return {
    rules: [
      {
        userAgent: "*",
        allow: [
          "/",
          "/movies",
          "/tv",
          "/country",
          "/search",
          "/person/",
          "/network/",
          "/company/",
          "/keyword/",
          "/about",
          "/contact",
          "/terms",
          "/privacy",
        ],
        disallow: [
          "/api/",
          "/watch/",
          "/profile",
          "/my-list",
          "/login",
          "/register",
          "/offline",
        ],
      },
    ],
    sitemap: [
      `${base}/sitemap.xml`,
      `${base}/sitemap-movie.xml`,
      `${base}/sitemap-tv.xml`,
      `${base}/sitemap-person.xml`,
      `${base}/sitemap-network.xml`,
      `${base}/sitemap-company.xml`,
    ],
  };
}
